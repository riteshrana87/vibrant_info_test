<head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title><?php echo e(config('app.name', 'Contract')); ?></title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('front/images/favicon.svg')); ?>" />

    <!-- ========================= CSS here ========================= -->
    <link rel="stylesheet" href="<?php echo e(asset('front/css/bootstrap.min.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('front/css/LineIcons.3.0.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('front/css/animate.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('front/css/tiny-slider.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('front/css/glightbox.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('front/css/main.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('front/css/coustom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/contract.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/sweetalert.css')); ?>">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
    <?php 
    if (isset($headerCss) && count($headerCss) > 0) {
      foreach ($headerCss as $css) { ?>
        <link href="<?php echo e(asset($css)); ?>" rel="stylesheet" type="text/css" />
        <?php } } ?>


    <?php echo $__env->yieldContent("css_section"); ?>
</head><?php /**PATH C:\xampp\htdocs\eq-ritesh-r-laravel-practical\resources\views/front/layouts/header.blade.php ENDPATH**/ ?>