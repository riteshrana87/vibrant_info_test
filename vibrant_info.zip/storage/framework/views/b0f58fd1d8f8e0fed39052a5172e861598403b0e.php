<header class="header navbar-area others-pages">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <div class="nav-inner">
                        <!-- Start Navbar -->
                        <nav class="navbar navbar-expand-lg">
                        <?php if(isset(Auth::user()->role_id) && Auth::user()->role_id == 2){
                                $url = url('/front/dashboard');
                            }else{
                                $url = "";
                            }?>
                            <a class="navbar-brand" href="<?php echo e($url); ?>">
                                <img src="<?php echo e(asset('front/images/logo/Logo.jpg')); ?>" alt="Logo">
                            </a>
                            <button class="navbar-toggler mobile-menu-btn" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                                <span class="toggler-icon"></span>
                            </button>
                            <?php if(isset(Auth::user()->role_id) && Auth::user()->role_id == 2): ?>
                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul id="nav" class="navbar-nav ms-auto">
                                    <li class="nav-item">
                                        <a class="dd-menu collapsed <?php echo e(request()->is('front/dashboard*') ? 'active' : ''); ?>" href="<?php echo e(url('/front/dashboard')); ?>">Dashboard</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="dd-menu collapsed <?php echo e(request()->is('front/leave*') ? 'active' : ''); ?>" href="<?php echo e(url('/front/leave')); ?>">Leave</a>
                                    </li>
                                </ul>
                                <div class="button">
                                <ul id="nav" class="navbar-nav ms-auto">
                                    <li class="nav-item">
                                        <a class="dd-menu collapsed <?php echo e(request()->is('front/profile*') ? 'active' : ''); ?>" href="#" data-bs-toggle="collapse"
                                            data-bs-target="#submenu-1-1" aria-controls="navbarSupportedContent"
                                            aria-expanded="false" aria-label="Toggle navigation">My account</a>
                                        <ul class="sub-menu collapse" id="submenu-1-1">
                                            <li class="nav-item"><a href="<?php echo e(url('/front/logout')); ?>">Logout</a></li>
                                            <li class="nav-item"><a href="<?php echo e(url('/front/profile/'.Auth::user()->id)); ?>">Profile</a></li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                            </div> <!-- navbar collapse -->
                            
                            <?php else: ?>
                            <div class="collapse navbar-collapse sub-menu-bar" id="navbarSupportedContent">
                                <ul id="nav" class="navbar-nav ms-auto">
                                    <li class="nav-item">
                                        <a class="dd-menu <?php echo e(request()->is('/') ? 'active' : ''); ?> collapsed" href="<?php echo e(route('dashboard')); ?>">Home</a>
                                    </li>
                                    
                                </ul>
                                <div class="button">
                                <a href="<?php echo e(route('loginPage')); ?>" class="signin">Sign In</a>
                                <a href="<?php echo e(route('frontSignup')); ?>" class="signup">Sign Up</a>
                            </div>
                            </div> <!-- navbar collapse -->
                           
                            <?php endif; ?>
                        </nav>
                        <!-- End Navbar -->
                    </div>
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </header><?php /**PATH C:\xampp\htdocs\eq-ritesh-r-laravel-practical\resources\views/front/layouts/sidebar.blade.php ENDPATH**/ ?>