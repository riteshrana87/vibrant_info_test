

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
          <div class="row justify-content-center">
            <div class="col-12">
              <h2 class="page-title">Client Management</h2>
              <div class="row">
                <div class="col-md-12">
                  <div class="card shadow mb-4">
                    <div class="card-header">
                      <strong class="card-title">Edit Client</strong>
                    </div>
                    <div class="card-body">
                    <?php echo $__env->make('message_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form class="needs-validation" novalidate id="edit_form" name="edit_form" action="<?php echo e(route('update_employees', $userdata->id)); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>            
                        <div class="form-row">
                          <div class="col-md-6 mb-3">
                            <label for="comp_name">Name <span class="astrick">*</span></label>
                                <input type="text" class="form-control" id="comp_name" placeholder="Name" name="name" value="<?php echo e(!empty(old('name'))?old('name'):$userdata->name); ?>">
                                 <?php if($errors->has('company_name')): ?>
                                    <div class="invalid-feedback"><?php echo e($errors->first('company_name')); ?></div>
                                  <?php endif; ?>
                          </div>
                          <div class="col-md-6 mb-3">
                              <label for="email">Email <span class="astrick">*</span></label>
                              <input type="text" class="form-control validateEmail" id="email" placeholder="Email Id" name="email" value="<?php echo e(!empty(old('email'))?old('email'):$userdata->email); ?>">
                              <?php if($errors->has('email')): ?>
                                <div class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                              <?php endif; ?>
                          </div>
                          <div class="col-md-6 mb-3">
                            <label for="address">Address</label>
                                <input id="address" type="text" class="form-control" name="address" placeholder="Address" value="<?php echo e(!empty(old('address'))?old('address'):$userdata->address); ?>">
                                <div class="invalid-feedback"><?php echo e($errors->first('address')); ?></div>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="phone">Phone</label>
                                <input id="phone" type="text" class="form-control onlynum" name="phone" placeholder="Phone" value="<?php echo e(!empty(old('phone'))?old('phone'):$userdata->phone); ?>">
                                <div class="invalid-feedback"><?php echo e($errors->first('phone')); ?></div>
                        </div>
                        <div class="col-md-6 mb-3">
                          <label for="phone">DOB</label>
                              <input id="dob" type="text" class="form-control onlynum" name="dob" placeholder="DOB" value="<?php echo e(!empty(old('DOB'))?old('DOB'):$userdata->DOB); ?>">
                              <div class="invalid-feedback"><?php echo e($errors->first('dob')); ?></div>
                      </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Save</button>
                      </form>
                    </div> <!-- /.card-body -->
                  </div> <!-- /.card -->
                </div> <!-- /.col -->   
              </div> <!-- end section -->
            </div> <!-- /.col-12 col-lg-10 col-xl-10 -->
          </div> <!-- .row -->
        </div> <!-- .container-fluid -->
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eq-ritesh-r-laravel-practical\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>