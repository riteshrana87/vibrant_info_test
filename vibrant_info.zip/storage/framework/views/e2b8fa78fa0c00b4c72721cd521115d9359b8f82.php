<!-- Alert messages code start here -->		
<?php if($errors->any()): ?>
				<div class="alert alert-danger mb-4 alertmsg" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i data-feather="x" class="close"></i></button>
					<i data-feather="alert-circle"></i> <strong>Error! </strong>
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if(session()->get('success')): ?>          
				<div class="alert alert-success mb-4 alertmsg" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i data-feather="x" class="close"></i></button>
					<i data-feather="check"></i> <strong>Success! </strong> <?php echo e(session()->get('success')); ?>

				</div>
			<?php endif; ?>

			<?php if(session()->get('error')): ?>            
				<div class="alert alert-danger mb-4 alertmsg" role="alert">
					<button type="button" class="close" data-dismiss="alert" aria-label="Close"> <i data-feather="x" class="close"></i></button>
					<i data-feather="alert-circle"></i> <strong>Error! </strong><?php echo e(session()->get('error')); ?>

				</div>
			<?php endif; ?>
			<!-- Alert messages code end here --><?php /**PATH C:\xampp\htdocs\eq-ritesh-r-laravel-practical\resources\views/message_data.blade.php ENDPATH**/ ?>