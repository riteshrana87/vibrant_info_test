<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo e(asset('admin/images/favicon.png')); ?>}">
    <title><?php echo e(config('app.name', 'Contract')); ?></title>
    <?php echo $__env->yieldContent("css_section"); ?>
    <!-- Simple bar CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/simplebar.css')); ?> ">
    <!-- Fonts CSS -->
    <link href="https://fonts.googleapis.com/css2?family=Overpass:ital,wght@0,100;0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <!-- Icons CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/dataTables.bootstrap4.css')); ?>">
    <!-- Date Range Picker CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/daterangepicker.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/coustom.css')); ?>">
    <!-- App CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/app-light.css')); ?>" id="lightTheme">
    <link rel="stylesheet" href="<?php echo e(asset('front/css/sweetalert.css')); ?>">
    <link href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/datepicker/1.0.10/datepicker.min.css">

    
    <?php 
    if (isset($headerCss) && count($headerCss) > 0) {
      foreach ($headerCss as $css) { ?>
        <link href="<?php echo e(asset($css)); ?>" rel="stylesheet" type="text/css" />
        <?php } } ?>
  <?php echo $__env->yieldPushContent('style'); ?> 
  </head>

<body class="vertical  light">
    <div class="wrapper">

    <!--header--->
    <?php echo $__env->make('admin.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end--header-->

    <!--header--->
    <?php echo $__env->make('admin.include.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--end--header-->
    <!-- help panel end -->
    <!-- Content Wrapper. Contains page content -->
    <main role="main" class="main-content">
            <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>

<!-- ./wrapper -->
<script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/popper.min.js')); ?> "></script>
<script src="<?php echo e(asset('admin/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/simplebar.min.js')); ?> "></script>
<script src="<?php echo e(asset('admin/js/daterangepicker.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/jquery.stickOnScroll.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/tinycolor-min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/config.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>

<script src="<?php echo e(asset('front/js/sweetalert.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>

<script src="<?php echo e(asset('front/js/my-custom.js')); ?>"></script>
<script type="text/javascript">
        var baseurl = <?php echo "'".url('/')."';"; ?>;
        var csrf_token = <?php echo "'".csrf_token()."';"; ?>
</script>
<?php
/*
  @Author : Ritesh Rana
  @Desc   : Used for the custom js initilization just pass array of the scripts with links
  @Input  :
  @Output :
  @Date   : 15/05/2021
 */
if (isset($footerJs) && count($footerJs) > 0) {
foreach ($footerJs as $js) { ?>
<script src="<?php echo e(asset($js)); ?>" ></script>
<?php }} ?>
<script>
  var backendUrl = "<?php echo e(url('/')); ?>"
      /* $('#dataTable-1').DataTable(
      {
        autoWidth: true,
        "lengthMenu": [
          [16, 32, 64, -1],
          [16, 32, 64, "All"]
        ]
      }); */
    </script>
    <script src="<?php echo e(asset('admin/js/apps.js')); ?>"></script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-56159088-1"></script>
    <script>
      window.dataLayer = window.dataLayer || [];

      function gtag()
      {
        dataLayer.push(arguments);
      }
      gtag('js', new Date());
      gtag('config', 'UA-56159088-1');
    </script>
     <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('script'); ?>
<?php echo $__env->yieldContent("js_section"); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\eq-ritesh-r-laravel-practical\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>